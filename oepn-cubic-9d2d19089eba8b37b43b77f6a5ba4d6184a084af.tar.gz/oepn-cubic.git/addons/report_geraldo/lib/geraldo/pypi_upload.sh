#!/bin/bash
python setup.py sdist upload
#python setup.py bdist upload
