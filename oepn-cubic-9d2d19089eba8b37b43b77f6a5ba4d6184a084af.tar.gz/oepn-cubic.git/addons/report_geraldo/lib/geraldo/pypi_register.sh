#!/bin/bash
python setup.py register
