VERSION = (0, 4, 17)

def get_version():
    return '%d.%d.%d'%VERSION

